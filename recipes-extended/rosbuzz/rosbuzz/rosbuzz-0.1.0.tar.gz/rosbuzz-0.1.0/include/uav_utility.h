#ifndef UAV_UTILITY_H
#define UAV_UTILITY_H

extern void uav_setup();

extern void uav_done();


#endif
